# Student Auth API (JWT + Roles)

## Run
1. `npm install`
2. Start MongoDB, check `.env`
3. `npm start` -> http://localhost:3000

## Endpoints
| Method | URL | Access | Notes |
|--------|-----|--------|-------|
| POST | /register | public | name, email, password (min 6), role (student/admin) |
| POST | /login | public | returns JWT (expires in 1 hour) |
| GET | /profile | logged-in | header `Authorization: Bearer <token>`; no password returned |
| GET | /students | admin only | 401 no/invalid token, 403 non-admin |

## Postman test order
1. Register a student and an admin.
2. Login as each, copy the tokens.
3. GET /profile with and without token (200 / 401).
4. GET /students with admin token (200) and student token (403).
