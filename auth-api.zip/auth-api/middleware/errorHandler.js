module.exports = (err, req, res, next) => {
  if (err.type === 'entity.parse.failed') {
    return res.status(400).json({ error: 'Invalid JSON body' });
  }
  if (err.code === 11000) {
    return res.status(409).json({ error: 'Email already registered' });
  }
  console.error(err);
  res.status(500).json({ error: 'Internal server error' });
};
