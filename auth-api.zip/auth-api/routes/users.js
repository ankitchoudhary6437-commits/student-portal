const express = require('express');
const User = require('../models/User');
const { authMiddleware, requireRole } = require('../middleware/authMiddleware');

const router = express.Router();

// GET /profile - any logged-in user
router.get('/profile', authMiddleware, async (req, res, next) => {
  try {
    const user = await User.findById(req.user.id).select('-password');
    if (!user) return res.status(404).json({ error: 'User not found' });
    res.status(200).json(user);
  } catch (err) {
    next(err);
  }
});

// GET /students - admins only (others get 403)
router.get('/students', authMiddleware, requireRole('admin'), async (req, res, next) => {
  try {
    const students = await User.find({ role: 'student' }).select('-password');
    res.status(200).json(students);
  } catch (err) {
    next(err);
  }
});

module.exports = router;
